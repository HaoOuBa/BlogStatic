import { EditorView } from '@codemirror/view';
import { EditorState } from '@codemirror/state';
import { markdown, markdownLanguage } from '@codemirror/lang-markdown';
import { languages } from '@codemirror/language-data';
import theme from './theme';
new EditorView({
	state: EditorState.create({
		doc: document.querySelector('textarea').value,
		extensions: [
			theme(),
			markdown({
				base: markdownLanguage,
				codeLanguages: languages
			})
		]
	}),
	parent: document.querySelector('body')
});

import { HighlightStyle, tags } from '@codemirror/highlight';

export default () => {
	return HighlightStyle.define([
		{
			tag: tags.punctuation,
			color: '#808080'
		},
		{
			tag: tags.name,
			color: '#d19a66'
		},
		{
			tag: tags.propertyName,
			color: '#96c0d8'
		},
		{
			tag: tags.string,
			color: '#98c379'
		},
		{
			tag: tags.keyword,
			color: '#c678dd'
		},
		{
			tag: tags.operator,
			color: '#96c0d8'
		},
		{
			tag: tags.variableName,
			color: '#e06c75'
		},
		{
			tag: tags.number,
			color: '#d19a66'
		},
		{
			tag: tags.comment,
			color: '#6a9955'
		},
		{
			tag: tags.processingInstruction,
			color: '#abb2bf'
		},
		{
			tag: tags.labelName,
			color: '#abb2bf'
		},
		{
			tag: tags.definition(tags.propertyName),
			color: '#e06c75'
		},
		{
			tag: tags.definition(tags.variableName),
			color: '#e5c07b'
		},
		{
			tag: tags.local(tags.variableName),
			color: '#d19a66'
		},
		{
			tag: tags.atom,
			color: '#d19a66'
		},
		{
			tag: tags.meta,
			color: '#abb2bf'
		},
	]);
};
